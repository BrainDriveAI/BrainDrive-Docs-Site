---
title: "BrainDrive Release x.x.x"
description: "Overview of changes and new features in this release."
doc_type: release-notes
product_area: core
owner: "@release-team"
source_of_truth: "repo"
last_verified: 2025-09-23
version: "x.x.x"
---

## Highlights

Summarize the most important user‑visible changes.

## Breaking Changes

List any breaking changes with clear migration instructions.

## New Features

- Describe new features and enhancements.

## Bug Fixes

- Describe notable bug fixes.

## Upgrade Notes

Provide instructions or caveats for upgrading from previous versions.
